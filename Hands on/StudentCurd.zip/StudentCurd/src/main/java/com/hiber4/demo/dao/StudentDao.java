package com.hiber4.demo.dao;

public interface StudentDao
{
	public void addStd();
	public void deleteStd();
	public void editStd();
	public void displayStd();
	
	

}
